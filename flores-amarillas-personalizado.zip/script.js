function createFlower() {
    const flowerContainer = document.querySelector(".flower-container");

    // Número máximo de flores en pantalla
    const maxFlowersOnScreen = 15;

    if (document.querySelectorAll(".flower").length >= maxFlowersOnScreen) {
        return; // No crear más flores
    }

    // Número máximo de flores a crear simultáneamente (entre 1 y 5)
    const maxFlowers = Math.ceil(Math.random() * 5 + 1);

    // Las dos ilustraciones estilo acuarela
    const images = ["flor-amarilla.png", "flor-rosa.png"];

    for (let j = 0; j < maxFlowers; j++) {
        const flower = document.createElement("img");
        flower.classList.add("flower");
        flower.src = images[Math.floor(Math.random() * images.length)];
        flower.alt = "Flor";

        // Tamaño aleatorio entre 120 y 220 píxeles
        const size = Math.random() * 100 + 120;
        flower.style.width = `${size}px`;
        flower.style.height = "auto";

        // Posición horizontal aleatoria
        const randomX = Math.random() * (window.innerWidth - size);

        // Rotación aleatoria suave para que se vea más natural
        const rotation = (Math.random() - 0.5) * 30;

        // Duración de la caída entre 6 y 12 segundos
        const fallDuration = Math.random() * 6000 + 6000;

        flower.style.position = "fixed";
        flower.style.left = `${randomX}px`;
        flower.style.top = `-${size}px`;
        flower.style.transform = `rotate(${rotation}deg)`;
        flower.style.setProperty("--sway", `${(Math.random() - 0.5) * 80}px`);
        flower.style.animation = `fallFlower ${fallDuration}ms linear forwards, swayFlower 2.5s ease-in-out infinite alternate`;

        flowerContainer.appendChild(flower);

        // Eliminar la flor cuando termina de caer
        setTimeout(() => {
            if (flower.parentNode === flowerContainer) {
                flowerContainer.removeChild(flower);
            }
        }, fallDuration);
    }
}

// Nuevas flores cada 1 segundo
setInterval(createFlower, 1000);
